from django import template

register = template.Library()

def left(value, total):
	return (value % total) * 20

def top(value, total):
	return (value / total) * 20
	
register.filter('left',left)
register.filter('top',top)