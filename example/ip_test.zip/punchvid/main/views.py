# Create your views here.
from django.http import HttpResponse
from main.models import Block
from django.shortcuts import render_to_response

import socket
from random import shuffle

def fib(n):
	if n == 0:
		return 0
	if n == 1:
		return 1
	else:
		return fib(n-2) + fib(n-1)

def get_ip():
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect( ("google.com", 80) )
	ip = s.getsockname()[0]
	s.close()
	return ip

def ip(request):
  	return render_to_response("ip.html", {'ip':get_ip(),'fib':fib(25)})

def index(requset):
	blocks = Block.objects.all()
	return render_to_response("index.html", {'blocks':blocks})
	

def hit(request, vm_id):
	blocks = Block.objects.filter(covered=True)
	
	if len(blocks) > 0:
		raw_blocks = [block for block in blocks]
		shuffle(raw_blocks)
		b = raw_blocks[0]
		b.covered = False
		b.save()
	
	return render_to_response("index.html", {'blocks':Block.objects.all()})
	

def reset(request):
	blocks = Block.objects.all()
	if len(blocks) == 0:
		#Then we need to create the blocks!
		blocks = []
		for i in range(0,490):
			b = Block(key=i, covered=True)
			b.save()
			blocks += [b]
	else:
		for block in blocks:
			block.covered = True
			block.save()
	
	return render_to_response("index.html",{'blocks':blocks})
