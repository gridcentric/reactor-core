from django.db import models

# Create your models here.
class Block(models.Model):
	key = models.IntegerField()
	covered = models.BooleanField()
